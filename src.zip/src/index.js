const express = require('express');
const bodyParser = require('body-parser');
const route = require('./routes/route.js');
const mongoose = require('mongoose');
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

mongoose.connect("mongodb+srv://FunctionUp:surbhi_231%40123@cluster0.ufu0v.mongodb.net/Surbhi231?retryWrites=true&w=majority",
    { useNewUrlParser: true }) .then( () => console.log("Mongodb is connected")) .catch( err => console.log(err))



app.use('/', route);


app.listen(process.env.PORT || 3000, function () {
    console.log('Express app running on port ' + (process.env.PORT || 3000))
});
