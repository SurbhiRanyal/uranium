//const { default: mongoose } = require('mongoose');
const mangoose = require('mongoose');

const  bookSchema= new mongoose.Schema( {
        bookName: String,
        authorName: String,
        category: [ {_id: false,categoryID: { type:ObjectId,required: true,ref: 'Category' }}]
        year: { type: Number},
         ,timestamps:true})

          module.exports = mongoose.model('Book', bookSchema)