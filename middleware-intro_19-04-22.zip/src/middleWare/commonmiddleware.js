
const api = function(req,res,next) {
    let d = new Date
    console.log(d)
    res.send(d)
    next()

}

module.exports.api = api